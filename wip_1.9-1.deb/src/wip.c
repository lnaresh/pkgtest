#include<stdio.h>
int main(){
printf("world in peace wip_1.9-1");
}
